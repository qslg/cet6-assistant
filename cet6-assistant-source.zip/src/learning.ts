export type RecordEntry={star:boolean;seen:number;streak:number;due:number;last:number};
export type Progress={version:1;records:Record<string,RecordEntry>;daily:Record<string,string[]>;session:{ids:string[];index:number;label:string;pool?:string[]}};
export const KEY='cijian-cet6-v1';
export const dayKey=(date=new Date())=>`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
export const emptyRecord=():RecordEntry=>({star:false,seen:0,streak:0,due:0,last:0});
export function gradeRecord(old:RecordEntry|undefined,grade:'again'|'hard'|'good',now=Date.now()):RecordEntry{
 const r=old??emptyRecord();const streak=grade==='good'?Math.min(r.streak+1,5):0;
 const delay=grade==='again'?10*60*1000:grade==='hard'?86400000:[1,3,7,14,30][streak-1]*86400000;
 return {...r,star:grade==='good'?r.star:true,seen:r.seen+1,streak,due:now+delay,last:now};
}
export function validateBackup(raw:unknown,validIds:Set<string>):Progress{
 if(!raw||typeof raw!=='object')throw Error('备份内容不是有效对象');
 const d=raw as Progress;
 if(d.version!==1||!d.records||typeof d.records!=='object'||Array.isArray(d.records)||!d.daily||typeof d.daily!=='object'||Array.isArray(d.daily))throw Error('不是词间的有效备份文件');
 if(Object.keys(d.records).length>validIds.size)throw Error('记录数量异常');
 const records:Record<string,RecordEntry>={};
 for(const [id,r] of Object.entries(d.records)){
  if(!validIds.has(id)||!r||typeof r!=='object'||typeof r.star!=='boolean'||!Number.isInteger(r.seen)||r.seen<0||r.seen>1000000||!Number.isInteger(r.streak)||r.streak<0||r.streak>5||![r.due,r.last].every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<1e14))throw Error('备份包含无效的学习记录');
  records[id]={star:r.star,seen:r.seen,streak:r.streak,due:r.due,last:r.last};
 }
 const daily:Record<string,string[]>={};
 for(const [day,ids] of Object.entries(d.daily)){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||!Array.isArray(ids)||ids.length>validIds.size||!ids.every(id=>typeof id==='string'&&validIds.has(id)))throw Error('备份的每日记录无效');
  daily[day]=[...new Set(ids)];
 }
 const s=d.session;
 const pool=s&&Array.isArray(s.pool)&&s.pool.length<=validIds.size&&s.pool.every(id=>typeof id==='string'&&validIds.has(id))?s.pool:undefined;
 const session=s&&Array.isArray(s.ids)&&s.ids.length<=validIds.size&&s.ids.every(id=>validIds.has(id))&&Number.isInteger(s.index)&&s.index>=0&&s.index<=s.ids.length&&typeof s.label==='string'&&s.label.length<=150?{ids:s.ids,index:s.index,label:s.label,...(pool?{pool}:{})}:{ids:[],index:0,label:'复习'};
 return {version:1,records,daily,session};
}
export function mergeProgress(current:Progress,incoming:Progress):Progress{
 const records={...current.records};
 for(const [id,r] of Object.entries(incoming.records)){const old=records[id];records[id]=old?{...(r.last>old.last?r:old),star:r.star||old.star}:r;}
 const daily={...current.daily};for(const [day,ids]of Object.entries(incoming.daily))daily[day]=[...new Set([...(daily[day]??[]),...ids])];
 return {...current,records,daily};
}
