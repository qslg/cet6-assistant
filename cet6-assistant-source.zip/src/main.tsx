import { createRoot } from 'react-dom/client';
import WordApp from './WordApp';
createRoot(document.getElementById('root')!).render(<WordApp />);
